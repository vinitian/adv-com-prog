package Task3;

public interface PaymentMethodFactory {
    public PaymentMethod createPaymentMethod();
}
