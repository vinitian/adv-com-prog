package Task3;

public class CryptoPayment implements PaymentMethod {
    
    public void processPayment(double amount) {
        System.out.println("Processing cryptocurrency payment of $" + amount);
    }
}
