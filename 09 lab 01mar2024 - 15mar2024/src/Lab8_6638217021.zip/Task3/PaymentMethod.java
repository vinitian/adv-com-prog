package Task3;

public interface PaymentMethod {
    void processPayment(double amount);
}
