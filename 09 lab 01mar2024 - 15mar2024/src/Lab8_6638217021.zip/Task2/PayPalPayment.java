package Task2;

public class PayPalPayment implements PaymentMethod {
    
    public void processPayment(double amount) {
        System.out.println("Processing PayPal payment of $" + amount);
    }
}
