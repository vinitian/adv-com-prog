package Task2;

public interface PaymentMethod {
    public void processPayment(double amount);
}
