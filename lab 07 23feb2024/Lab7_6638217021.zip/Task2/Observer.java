package Task2;

public interface Observer {
    public void open();
    public void close();
}
