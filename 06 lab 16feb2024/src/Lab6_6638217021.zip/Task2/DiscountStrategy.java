package Task2;

public interface DiscountStrategy {
    public double discount(double discount, double total);
}
